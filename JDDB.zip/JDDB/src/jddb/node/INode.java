package jddb.node;

public interface INode
{
	public void start();
	
	public void stop();
}
